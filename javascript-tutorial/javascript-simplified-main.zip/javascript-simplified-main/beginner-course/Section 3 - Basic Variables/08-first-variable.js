let a = 1
console.log(a)

let b = 2
console.log(b)

let c = 3
console.log(c)

a = 3
console.log(a)
