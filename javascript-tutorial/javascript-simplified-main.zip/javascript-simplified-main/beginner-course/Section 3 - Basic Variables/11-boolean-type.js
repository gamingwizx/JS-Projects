let happy = true
let fun = true

console.log(happy && fun)
