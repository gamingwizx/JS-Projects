let name = "Spencer"

console.log("Hello, my name is " + name)
