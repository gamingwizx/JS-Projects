/**
 * Activity 1: Create a for loop that loops from 0 to 10 and
 * prints out all values from 0 to 10 (inclusive).
 */
for (let i = 0; i <= 10; i++) {
	console.log(i)
}

/**
 * Activity 2: Take the loop from Activity 1 and modify it
 * so that the loop exits when the value is equal to 5 by
 * using the break keyword.
 */
for (let i = 0; i <= 10; i++) {
	if (i === 5) break
	console.log(i)
}
