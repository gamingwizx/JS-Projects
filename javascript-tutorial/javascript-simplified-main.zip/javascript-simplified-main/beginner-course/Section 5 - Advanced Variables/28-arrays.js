// Activity 1: Create an array with the first 5 letters of the
// alphabet, then print out the middle element in the array ('c').
const alphabet = ["a", "b", "c", "d", "e"]
console.log(alphabet[2]) // 'c'

// Activity 2: With the given nested arrays, print out the
// values 4, 8, and 11.
const a = [
	[1, 2, 3, 4, 5],
	[6, 7, 8, 9, 10],
	[11, 12, 13, 14, 15]
]
console.log(a[0][3]) // 4
console.log(a[1][2]) // 8
console.log(a[2][0]) // 11
