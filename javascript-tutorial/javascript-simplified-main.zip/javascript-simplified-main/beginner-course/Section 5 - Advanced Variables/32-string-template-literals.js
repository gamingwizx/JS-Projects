// Activity 1: Create two variables, one for your first name
// and one for your last name, then combine them together
// using back-ticks (string template literals).
const firstName = "Spencer"
const lastName = "Meredith"

console.log(`${firstName} ${lastName}`)
