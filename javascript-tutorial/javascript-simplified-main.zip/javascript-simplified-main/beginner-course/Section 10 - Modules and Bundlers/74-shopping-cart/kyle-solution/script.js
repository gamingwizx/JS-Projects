import { setupStore } from "./store.js"
import { setupShoppingCart } from "./shoppingCart.js"

setupStore()
setupShoppingCart()
