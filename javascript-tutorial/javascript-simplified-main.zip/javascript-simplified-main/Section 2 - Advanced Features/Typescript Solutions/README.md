# Typescript Solutions

This folder contains solutions to all of the exercises converted to Typescript. In a lot of cases, very little (if anything) needs to change in order to convert my original solutions to Typescript, but the point of this directory is to give me practice with the very basics of Typescript (mostly declaring all types to ensure type safety in my scripts), so I am going to convert my solutions for all exercises, regardless of how big or small the changes are.

For Typescript version of a project, see the directory for that project. It will have a sub-directory that contains the Typescript version of the project.
